package com.grobocop.dogapp

class Dog(name:String, photoURL: String, information : String)
{

    val dogName: String = name
    val photoURL: String = photoURL
    val information:String = information
}